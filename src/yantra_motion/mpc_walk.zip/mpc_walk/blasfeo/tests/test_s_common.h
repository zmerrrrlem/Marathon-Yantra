/**************************************************************************************************
*                                                                                                 *
* This file is part of BLASFEO.                                                                   *
*                                                                                                 *
* BLASFEO -- BLAS For Embedded Optimization.                                                      *
* Copyright (C) 2019 by Gianluca Frison.                                                          *
* Developed at IMTEK (University of Freiburg) under the supervision of Moritz Diehl.              *
* All rights reserved.                                                                            *
*                                                                                                 *
* The 2-Clause BSD License                                                                        *
*                                                                                                 *
* Redistribution and use in source and binary forms, with or without                              *
* modification, are permitted provided that the following conditions are met:                     *
*                                                                                                 *
* 1. Redistributions of source code must retain the above copyright notice, this                  *
*    list of conditions and the following disclaimer.                                             *
* 2. Redistributions in binary form must reproduce the above copyright notice,                    *
*    this list of conditions and the following disclaimer in the documentation                    *
*    and/or other materials provided with the distribution.                                       *
*                                                                                                 *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND                 *
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED                   *
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE                          *
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR                 *
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES                  *
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;                    *
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND                     *
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT                      *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS                   *
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.                                    *
*                                                                                                 *
* Author: Gianluca Frison, gianluca.frison (at) imtek.uni-freiburg.de                             *
*                                                                                                 *
**************************************************************************************************/

// BLASFEO routines
#include "../include/blasfeo_common.h"
#include "../include/blasfeo_s_blas.h"
#include "../include/blasfeo_s_aux.h"
#include "../include/blasfeo_s_kernel.h"

#include "../include/blasfeo_s_blas_api.h"

// BLASFEO External dependencies
#include "../include/blasfeo_i_aux_ext_dep.h"
#include "../include/blasfeo_v_aux_ext_dep.h"
#include "../include/blasfeo_s_aux_ext_dep.h"
#include "../include/blasfeo_timing.h"

// BLASFEO LA:REFERENCE routines
#include "../include/blasfeo_s_blasfeo_api_ref.h"
#include "../include/blasfeo_s_aux_ref.h"
#include "../include/blasfeo_s_aux_ext_dep_ref.h"

#include "../include/blasfeo_s_aux_test.h"
#include "../include/s_blas.h"

// Macros specific for Float type
#define PRECISION Single
#define GECMP_LIBSTR sgecmp_libstr
#define GECMP_BLASAPI sgecmp_blasapi
#define REAL float

#define ZEROS s_zeros
#define FREE s_free

#define STRMAT blasfeo_smat
#define STRVEC blasfeo_svec

#define ALLOCATE_STRMAT blasfeo_allocate_smat
#define FREE_STRMAT blasfeo_free_smat
#define GESE_LIBSTR blasfeo_sgese
#define PACK_STRMAT blasfeo_pack_smat
#define PRINT_STRMAT blasfeo_print_smat

#define PS S_PS

#define STRMAT_REF blasfeo_smat_ref
#define STRVEC_REF blasfeo_svec_ref

#define ALLOCATE_STRMAT_REF blasfeo_allocate_smat_ref
#define FREE_STRMAT_REF blasfeo_free_smat_ref
#define GESE_REF blasfeo_sgese_ref
#define GECP_REF blasfeo_sgecp_ref
#define PACK_STRMAT_REF blasfeo_pack_smat_ref
#define PRINT_STRMAT_REF blasfeo_print_smat_ref
