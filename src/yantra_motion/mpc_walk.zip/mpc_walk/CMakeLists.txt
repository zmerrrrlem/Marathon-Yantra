cmake_minimum_required(VERSION 3.8)
project(mpc_walk)

if(CMAKE_COMPILER_IS_GNUCXX OR CMAKE_CXX_COMPILER_ID MATCHES "Clang")
  add_compile_options(-Wall -Wextra -Wpedantic)
endif()

include_directories(blasfeo/include)
include_directories(hpipm/include)
add_subdirectory(blasfeo)
add_subdirectory(hpipm)
file(GLOB srcs "hpipm/include/*.h" "blasfeo/include/*.h")

find_package(PkgConfig REQUIRED)
set(THIS_PACKAGE_INCLUDE_DEPENDS
  hardware_interface
  pluginlib
  rclcpp
  rclcpp_lifecycle
  controller_interface
  generate_parameter_library
  parameter_traits
  realtime_tools
  std_msgs
  sensor_msgs
  control_msgs
  geometry_msgs
  kdl_parser
  Eigen3
  ament_index_cpp
  Boost
)



# Specify the required version of ros2_control
find_package(controller_manager 4.0.0)
# Handle the case where the required version is not found
if(NOT controller_manager_FOUND)
  message(FATAL_ERROR "ros2_control version 4.0.0 or higher is required. "
  "Are you using the correct branch of the ros2_control_demos repository?")
endif()
# find dependencies
find_package(backward_ros REQUIRED)
find_package(ament_cmake REQUIRED)
foreach(Dependency IN ITEMS ${THIS_PACKAGE_INCLUDE_DEPENDS})
find_package(${Dependency} REQUIRED)
endforeach()

add_library(
  quintic_walk SHARED
  src/quintic_walk.cpp
  src/MPCSolver.cpp
  )

target_compile_features(quintic_walk PUBLIC c_std_99 cxx_std_17)  # Require C99 and C++17

target_include_directories(quintic_walk PUBLIC
  $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/include>
  $<INSTALL_INTERFACE:include/${PROJECT_NAME}>)

generate_parameter_library(quintic_walk_parameters src/quintic_walk_parameters.yaml)

target_link_libraries(quintic_walk PUBLIC rclcpp::rclcpp quintic_walk_parameters blasfeo hpipm)
ament_target_dependencies(quintic_walk PUBLIC ${THIS_PACKAGE_INCLUDE_DEPENDS})

pluginlib_export_plugin_description_file(controller_interface quintic_walk_plugin.xml)

install(
  DIRECTORY launch config
  DESTINATION share/${PROJECT_NAME}
)

install(
  DIRECTORY include/
  DESTINATION include/${PROJECT_NAME}
)
install(
  TARGETS quintic_walk quintic_walk_parameters
  EXPORT export_${PROJECT_NAME}
  ARCHIVE DESTINATION lib
  LIBRARY DESTINATION lib
  RUNTIME DESTINATION bin
)


ament_export_include_directories(
  "include/${PROJECT_NAME}"
)
ament_export_libraries(
  quintic_walk
)
ament_export_targets(export_${PROJECT_NAME} HAS_LIBRARY_TARGET)

ament_package()
