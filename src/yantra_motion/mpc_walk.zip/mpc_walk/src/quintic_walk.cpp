#include "quintic_walk/quintic_walk.hpp"
#include "controller_interface/helpers.hpp"

namespace quintic_walk
{
controller_interface::CallbackReturn QuinticWalk::on_init()
{
  try
  {
    param_listener_ = std::make_shared<ParamListener>(get_node());
    params_ = param_listener_->get_params();
    RCLCPP_ERROR(get_node()->get_logger(), "initttttttttt");
  }
  catch (const std::exception& e)
  {
    fprintf(stderr, "Exception thrown during init stage with message: %s \n", e.what());
    return CallbackReturn::ERROR;
  }
  return CallbackReturn::SUCCESS;
}

controller_interface::CallbackReturn QuinticWalk::on_configure(const rclcpp_lifecycle::State& previous_state)
{
  control_cycle_msec_ = 8;
  iter = 0.0;
  params_ = param_listener_->get_params();

  uint8_t temp = 0;
  for (const auto& dxl : params_.joints)
  {
    dxls_key_.emplace_back(dxl);
  }
  for (const auto& sensor : params_.sensors)
  {
    sensor_key_.emplace_back(sensor);
  }
  // Initialize unordered map of sensor_state_
  for (const auto& interface : params_.sensor_interface)
  {
    for (const auto& sensor_ : sensor_key_)
    {
      if (sensor_ == "button")
        continue;
      sensor_state_[sensor_ + "/" + interface] = 0;
      std::cout << sensor_ + "/" + interface << std::endl;
    }
  }

  std::string path_to_urdf = ament_index_cpp::get_package_share_directory("altair_description");
  path_to_urdf += "/urdf/alfarobi.urdf";
  if (!kdl_parser::treeFromFile(path_to_urdf, mRobot))
  {
    RCLCPP_ERROR(get_node()->get_logger(), "Failed to construct kdl tree");
  }

  mRobot.getChain("body_link", "r_el_link", op3_right_arm_kinematic_chain_);
  mRobot.getChain("body_link", "l_el_link", op3_left_arm_kinematic_chain_);
  mRobot.getChain("r_ank_roll_link", "body_link", op3_right_leg_kinematic_chain_);
  mRobot.getChain("l_ank_roll_link", "body_link", op3_left_leg_kinematic_chain_);
  mRobot.getChain("r_ank_roll_link", "l_ank_roll_link", op3_right_foot_to_left_foot_kinematic_chain_);
  mRobot.getChain("l_ank_roll_link", "r_ank_roll_link", op3_left_foot_to_right_foot_kinematic_chain_);

  q_right_arm.resize(op3_right_arm_kinematic_chain_.getNrOfJoints());
  q0_right_arm.resize(op3_right_arm_kinematic_chain_.getNrOfJoints());
  qdot_right_arm.resize(op3_right_arm_kinematic_chain_.getNrOfJoints());
  J_right_arm.resize(op3_right_arm_kinematic_chain_.getNrOfJoints());
  q_right_arm(0) = 0.0;

  q_left_arm.resize(op3_left_arm_kinematic_chain_.getNrOfJoints());
  q0_left_arm.resize(op3_left_arm_kinematic_chain_.getNrOfJoints());
  qdot_left_arm.resize(op3_left_arm_kinematic_chain_.getNrOfJoints());
  q_left_arm(0) = 0.0;

  q_right_leg.resize(op3_right_leg_kinematic_chain_.getNrOfJoints());
  q0_right_leg.resize(op3_right_leg_kinematic_chain_.getNrOfJoints());
  qdot_right_leg.resize(op3_right_leg_kinematic_chain_.getNrOfJoints());
  J_right_leg.resize(op3_right_leg_kinematic_chain_.getNrOfJoints());
  J_rightf_to_leftf_leg.resize(op3_right_foot_to_left_foot_kinematic_chain_.getNrOfJoints());

  q_left_leg.resize(op3_left_leg_kinematic_chain_.getNrOfJoints());
  q0_left_leg.resize(op3_left_leg_kinematic_chain_.getNrOfJoints());
  qdot_left_leg.resize(op3_left_leg_kinematic_chain_.getNrOfJoints());

  J_left_leg.resize(op3_left_leg_kinematic_chain_.getNrOfJoints());
  J_leftf_to_rightf_leg.resize(op3_left_foot_to_right_foot_kinematic_chain_.getNrOfJoints());

  q0_sf_to_swg.resize(op3_left_foot_to_right_foot_kinematic_chain_.getNrOfJoints());
  q_sf_to_swg.resize(op3_left_foot_to_right_foot_kinematic_chain_.getNrOfJoints());

  right_arm_fk_solver.reset(new KDL::ChainFkSolverPos_recursive(op3_right_arm_kinematic_chain_));

  left_arm_fk_solver.reset(new KDL::ChainFkSolverPos_recursive(op3_left_arm_kinematic_chain_));

  right_leg_fk_solver.reset(new KDL::ChainFkSolverPos_recursive(op3_right_leg_kinematic_chain_));

  left_leg_fk_solver.reset(new KDL::ChainFkSolverPos_recursive(op3_left_leg_kinematic_chain_));

  left_foot_to_right_foot_fk_solver.reset(
      new KDL::ChainFkSolverPos_recursive(op3_left_foot_to_right_foot_kinematic_chain_));

  right_foot_to_left_foot_fk_solver.reset(
      new KDL::ChainFkSolverPos_recursive(op3_right_foot_to_left_foot_kinematic_chain_));

  right_arm_jacobian_solver.reset(new KDL::ChainJntToJacSolver(op3_right_arm_kinematic_chain_));
  right_leg_jacobian_solver.reset(new KDL::ChainJntToJacSolver(op3_right_leg_kinematic_chain_));
  left_leg_jacobian_solver.reset(new KDL::ChainJntToJacSolver(op3_left_leg_kinematic_chain_));

  right_foot_to_left_foot_jacobian_solver.reset(
      new KDL::ChainJntToJacSolver(op3_right_foot_to_left_foot_kinematic_chain_));
  left_foot_to_right_foot_jacobian_solver.reset(
      new KDL::ChainJntToJacSolver(op3_left_foot_to_right_foot_kinematic_chain_));

  x_right_arm_des = Eigen::VectorXd::Zero(6);
  x_right_arm_meas = Eigen::VectorXd::Zero(6);
  x_right_arm_vel_des = Eigen::VectorXd::Zero(6);
  x_right_leg_des = Eigen::VectorXd::Zero(6);
  x_right_leg_meas = Eigen::VectorXd::Zero(6);
  x_right_leg_vel_des = Eigen::VectorXd::Zero(6);
  x_left_leg_des = Eigen::VectorXd::Zero(6);
  x_left_leg_meas = Eigen::VectorXd::Zero(6);
  x_left_leg_vel_des = Eigen::VectorXd::Zero(6);
  sf_pose = Eigen::VectorXd::Zero(6);
  CoM_pose = Eigen::VectorXd::Zero(6);
  swg_pose = Eigen::VectorXd::Zero(6);
  CoM_pose_des = Eigen::VectorXd::Zero(6);
  swg_pose_des = Eigen::VectorXd::Zero(6);
  CoM_pose_meas = Eigen::VectorXd::Zero(6);
  swg_pose_meas = Eigen::VectorXd::Zero(6);

  J_stacked = Eigen::MatrixXd::Zero(12, 12);
  Id = Eigen::MatrixXd::Identity(12, 12);

  // initialize desired pose
  x_right_leg_des << 0.00, 0.035, 0.22, 0.0, 0.15, 0.0;
  x_left_leg_des << 0.00, -0.035, 0.22, 0.0, 0.15, 0.0;

  // initialize walk state
  walkState.mpcIter = 0;
  walkState.controlIter = 0;
  walkState.footstepCounter = 0;
  walkState.supportFoot = true;

  // initialize robot current and desired state
  current.comPos = Eigen::Vector3d(0.0, 0.0, comTargetHeight);
  current.comVel = Eigen::Vector3d(0.0, 0.0, 0.0);
  current.comAcc = Eigen::Vector3d(0.0, 0.0, 0.0);
  desired.comPos = Eigen::Vector3d(current.comPos(0), current.comPos(1), comTargetHeight);
  desired.comVel = Eigen::Vector3d::Zero();
  desired.zmpPos = Eigen::Vector3d(current.comPos(0), current.comPos(1), 0.0);
  desired.leftFootPos = Eigen::Vector3d(0.0, 0.039, 0.0);
  desired.rightFootPos = Eigen::Vector3d(0.0, -0.039, 0.0);
  desired.leftFootVel = Eigen::Vector3d(0.0, 0.0, 0.0);
  desired.leftFootAcc = Eigen::Vector3d(0.0, 0.0, 0.0);
  desired.rightFootVel = Eigen::Vector3d(0.0, 0.0, 0.0);
  desired.rightFootAcc = Eigen::Vector3d(0.0, 0.0, 0.0);

  desired.torsoOrient = Eigen::Vector3d(0.0, 0.0, 0.0);  //(0.0, 0.15, 0.0)
  desired.leftFootOrient = Eigen::Vector3d(0.0, 0.0, 0.0);
  desired.rightFootOrient = Eigen::Vector3d(0.0, 0.0, 0.0);
  desired.comAcc = eta * eta * (desired.comPos - desired.zmpPos);

  current.comAngVel = Eigen::Vector3d(0.0, 0.0, 0.0);
  current.comAngAcc = Eigen::Vector3d(0.0, 0.0, 0.0);
  current.leftFootVel = Eigen::Vector3d(0.0, 0.0, 0.0);
  current.rightFootVel = Eigen::Vector3d(0.0, 0.0, 0.0);
  current.leftFootAcc = Eigen::Vector3d(0.0, 0.0, 0.0);
  current.rightFootAcc = Eigen::Vector3d(0.0, 0.0, 0.0);
  current.leftFootAngVel = Eigen::Vector3d(0.0, 0.0, 0.0);
  current.rightFootAngVel = Eigen::Vector3d(0.0, 0.0, 0.0);
  current.leftFootAngAcc = Eigen::Vector3d(0.0, 0.0, 0.0);
  current.rightFootAngAcc = Eigen::Vector3d(0.0, 0.0, 0.0);

  desired.comAngVel = Eigen::Vector3d(0.0, 0.0, 0.0);
  desired.comAngAcc = Eigen::Vector3d(0.0, 0.0, 0.0);
  desired.leftFootVel = Eigen::Vector3d(0.0, 0.0, 0.0);
  desired.rightFootVel = Eigen::Vector3d(0.0, 0.0, 0.0);
  desired.leftFootAcc = Eigen::Vector3d(0.0, 0.0, 0.0);
  desired.rightFootAcc = Eigen::Vector3d(0.0, 0.0, 0.0);
  desired.leftFootAngVel = Eigen::Vector3d(0.0, 0.0, 0.0);
  desired.rightFootAngVel = Eigen::Vector3d(0.0, 0.0, 0.0);
  desired.leftFootAngAcc = Eigen::Vector3d(0.0, 0.0, 0.0);
  desired.rightFootAngAcc = Eigen::Vector3d(0.0, 0.0, 0.0);

  //  desired footsteps and timings in world frame
  int N_footsteps = 80;
  ftsp_and_time = Eigen::MatrixXd::Zero(N_footsteps, 4);

  for (int i = start; i < N_footsteps; i++)
  {
    ftsp_and_time(i, 0) = (i - start) * 0.00;  // 0.156
    if (i == start)
      ftsp_and_time(i, 1) = pow(-(double)1, (i - start)) * 0.049;
    else
      ftsp_and_time(i, 1) = pow(-(double)1, (i - start)) * 0.049;  // 0.08  0.035
    ftsp_and_time(i, 2) = 0.0;
    ftsp_and_time(i, 3) = (double)(s_ + f_) * i;
  }
  int start_ = 4;
  for (int i = start_; i < N_footsteps; i++)
  {
    ftsp_and_time(i, 0) = (i - start_) * stride_length;
  }

  for (int i = n_steps + 1; i < N_footsteps; i++)
  {
    ftsp_and_time(i, 0) = ftsp_and_time(n_steps, 0);
    ftsp_and_time(i, 1) = 0.5 * (ftsp_and_time(n_steps, 1) + ftsp_and_time(n_steps - 1, 1));
  }

  /*
  ftsp_and_time(6,2) = 0.025;
  ftsp_and_time(8,2) = -0.015;
  ftsp_and_time(9,2) = -0.04;
  ftsp_and_time(10,2) = -0.04;
  /**/
  // ftsp_and_time(7,2) = 0.01;

  // initialize mpc solver
  const Eigen::MatrixXd& ftsp_and_time_ref = ftsp_and_time;
  solver = new MPCSolver(ftsp_and_time_ref);

  rate = 1000.0 / control_cycle_msec_;

  T = 1000.0 * control_cycle_msec_ / 1000.0;

  t_start = 500;
  t_stand = 1500;
  t_walk = t_stand + (n_steps + 1) * (S + F);
  t_sit = t_walk + (t_stand - t_start);
  T = (double)(t_stand - t_start) * (double)control_cycle_msec_ / 1000.0;

  mode = "wait";

  return CallbackReturn::SUCCESS;
}

controller_interface::CallbackReturn QuinticWalk::on_activate(const rclcpp_lifecycle::State& previous_state)
{
  // Handle controller restarts and dynamic parameter updating
  // ...
  return CallbackReturn::SUCCESS;
}

controller_interface::CallbackReturn QuinticWalk::on_deactivate(const rclcpp_lifecycle::State& /*previous_state*/)
{
  return CallbackReturn::SUCCESS;
}

controller_interface::CallbackReturn QuinticWalk::on_cleanup(const rclcpp_lifecycle::State& previous_state)
{
  // Callback function for cleanup transition
  // ...
  return CallbackReturn::SUCCESS;
}

controller_interface::CallbackReturn QuinticWalk::on_shutdown(const rclcpp_lifecycle::State& previous_state)
{
  // Callback function for shutdown transition
  // ...
  return CallbackReturn::SUCCESS;
}

controller_interface::CallbackReturn QuinticWalk::on_error(const rclcpp_lifecycle::State& previous_state)
{
  // Callback function for erroneous transition
  // ...
  return CallbackReturn::SUCCESS;
}

controller_interface::InterfaceConfiguration QuinticWalk::command_interface_configuration() const
{
  controller_interface::InterfaceConfiguration command_interfaces_config;
  command_interfaces_config.type = controller_interface::interface_configuration_type::ALL;
  return command_interfaces_config;
}

controller_interface::InterfaceConfiguration QuinticWalk::state_interface_configuration() const
{
  controller_interface::InterfaceConfiguration state_interfaces_config;
  state_interfaces_config.type = controller_interface::interface_configuration_type::ALL;
  return state_interfaces_config;
}

controller_interface::return_type QuinticWalk::update(const rclcpp::Time& time, const rclcpp::Duration& period)
{
  // READ DXLs DATA & SENSORs DATA
  std::string prefix_name_temp;
  for (const auto& state : state_interfaces_)
  {
    prefix_name_temp = state.get_prefix_name();
    if (prefix_name_temp == sensor_key_[0])
    {
      sensor_state_[state.get_name()] = state.get_value();
    }
    else if (prefix_name_temp == sensor_key_[1])
    {
      sensor_state_[state.get_name()] = state.get_value();
    }
    else
    {
      dxls_state_[prefix_name_temp] = state.get_value();
    }
  }

  angular_rates << sensor_state_[sensor_key_[0] + "/linear_acceleration.y"],
      sensor_state_[sensor_key_[0] + "/angular_velocity.y"], sensor_state_[sensor_key_[0] + "/angular_velocity.z"];
  linear_acc << sensor_state_[sensor_key_[0] + "/linear_acceleration.x"],
      sensor_state_[sensor_key_[0] + "/linear_acceleration.y"],
      sensor_state_[sensor_key_[0] + "/linear_acceleration.z"];
  KDL::Rotation::Quaternion(
      sensor_state_[sensor_key_[0] + "/orientation.x"], sensor_state_[sensor_key_[0] + "/orientation.y"],
      sensor_state_[sensor_key_[0] + "/orientation.z"], sensor_state_[sensor_key_[0] + "/orientation.w"])
      .GetRPY(rpy(0), rpy(1), rpy(2));

  auto start = std::chrono::high_resolution_clock::now();
  if (enable_ == false)
    return controller_interface::return_type::OK;

  uint8_t temp_index = 0;
  for (const auto& dxl : command_interfaces_)
  {
    dxls_index_[dxl.get_prefix_name()] = temp_index;
    temp_index++;
  }
  temp_index = 0;

  if (mode == "wait")
  {
    command_interfaces_[dxls_index_["l_hip_yaw"]].set_value(0);
    command_interfaces_[dxls_index_["l_hip_yaw"]].set_value(0 * 0.0175);
    command_interfaces_[dxls_index_["l_hip_roll"]].set_value(0 * 0.0175);
    command_interfaces_[dxls_index_["l_hip_pitch"]].set_value(-70 * 0.0175);
    command_interfaces_[dxls_index_["l_knee"]].set_value(142 * 0.0175);
    command_interfaces_[dxls_index_["l_ank_pitch"]].set_value(70 * 0.0175);
    command_interfaces_[dxls_index_["l_ank_roll"]].set_value(0 * 0.0175);

    command_interfaces_[dxls_index_["r_hip_yaw"]].set_value(0 * 0.0175);
    command_interfaces_[dxls_index_["r_hip_roll"]].set_value(0 * 0.0175);
    command_interfaces_[dxls_index_["r_hip_pitch"]].set_value(70 * 0.0175);
    command_interfaces_[dxls_index_["r_knee"]].set_value(-142 * 0.0175);
    command_interfaces_[dxls_index_["r_ank_pitch"]].set_value(-70 * 0.0175);
    command_interfaces_[dxls_index_["r_ank_roll"]].set_value(0 * 0.0175);

    command_interfaces_[dxls_index_["l_sho_pitch"]].set_value(-15 * 0.0175);
    command_interfaces_[dxls_index_["l_sho_roll"]].set_value(45 * 0.0175);
    command_interfaces_[dxls_index_["l_el"]].set_value(-45 * 0.0175);

    command_interfaces_[dxls_index_["r_sho_pitch"]].set_value(15 * 0.0175);
    command_interfaces_[dxls_index_["r_sho_roll"]].set_value(-45 * 0.0175);
    command_interfaces_[dxls_index_["r_el"]].set_value(45 * 0.0175);
  }
  //********************
  // OPERATION MODES:
  //********************

  // initial setup before stand up motion
  if (iter == t_start - 1)
  {
    left_leg_fk_solver->JntToCart(q0_left_leg, x_left_leg_fk);
    z0 = x_left_leg_fk.p(2) + 0.008;
    zf = comTargetHeight;
    a3 = (zf - z0) / (pow(T, 3) - pow(T, 4) * 3.0 / (2.0 * T));
    a2 = -3.0 * a3 * pow(T, 2) / (2.0 * T);
    a0 = z0;
    a1 = 0.0;
  }

  // stand up motion
  if (iter >= t_start && iter < t_stand)
  {
    t = (iter - t_start) * control_cycle_msec_ / 1000.0;
    desired.comPos << desired.leftFootPos(0),
        ((double)iter - (double)t_start) * (desired.leftFootPos(1) - 0.043) / 1000.0,
        a3 * pow(t, 3) + a2 * pow(t, 2) + a1 * t + a0;
    desired.comVel(2) = 3.0 * a3 * pow(t, 2) + 2.0 * a2 * t + a1;
    desired.torsoOrient << 0.0, ((double)iter - (double)t_start) * 0.12 / 1000.0, 0.0;
    desired.rightFootPos << 0.0, -0.045, 0.0;
    desired.rightFootOrient << 0.0, 0.0, 0.0;
    mode = "stand up";
  }

  // walk motion
  if (iter >= t_stand)
  {
    if (walkState.simulationTime >= ftsp_and_time(walkState.footstepCounter, 3) - 1)
    {
      walkState.controlIter = 0;
      walkState.mpcIter = 0;
      walkState.footstepCounter++;
      walkState.supportFoot = !walkState.supportFoot;
      std::cout << iter << std::endl;
    }
    walkState.simulationTime = iter - t_stand;
    // compute MPC iteration and swing foot trajectory
    // const Eigen::MatrixXd& ftsp_and_time_ref = ftsp_and_time;
    if (walkState.footstepCounter < n_steps + 2)
      desired = solver->solve(desired, walkState, ftsp_and_time);
    ++walkState.controlIter;
    walkState.mpcIter = floor(walkState.controlIter * controlTimeStep / mpcTimeStep);
    // arm swing
    q_left_arm(0) = -0.1 + 0.15 * sin(2.0 * 3.14 * (iter - t_stand) / ((double)s_ * 2.0 + (double)f_ * 2.0));
    q_right_arm(0) = +0.1 + 0.15 * sin(2.0 * 3.14 * (iter - t_stand) / ((double)s_ * 2.0 + (double)f_ * 2.0));
    mode = "walk";
  }

  // initial setup before sit down motion
  if (iter == t_walk - 1)
  {
    left_leg_fk_solver->JntToCart(q0_left_leg, x_left_leg_fk);
    zf = z0;
    z0 = comTargetHeight;
    a3 = (zf - z0) / (pow(T, 3) - pow(T, 4) * 3.0 / (2.0 * T));
    a2 = -3.0 * a3 * pow(T, 2) / (2.0 * T);
    a0 = z0;
    a1 = 0.0;
  }

  // // sit down motion
  if (iter >= t_walk && iter < t_sit)
  {
    t = (iter - t_walk) * control_cycle_msec_ / 1000.0;
    desired.comPos(2) = a3 * pow(t, 3) + a2 * pow(t, 2) + a1 * t + a0;
    desired.comVel(2) = 3.0 * a3 * pow(t, 2) + 2.0 * a2 * t + a1;
    desired.torsoOrient(1) = 0.12 - ((double)iter - (double)t_walk) * 0.12 / 1000.0;
    mode = "sit down";
  }

  //***************
  // MEASUREMENTS:
  //***************

  storeEncoderReadings();
  computeDirectKinematics();

  //*************************
  // KINEMATIC CONTROLLER:
  //*************************

  if (iter >= t_start && iter < t_sit)
    computeInverseKinematicsWholeBody();

  //*******************
  // MOTOR COMMANDS:
  //*******************

  if (iter >= t_start && iter < t_sit)
  {
    command_interfaces_[dxls_index_["l_hip_yaw"]].set_value(q_left_leg(5));
    command_interfaces_[dxls_index_["l_hip_roll"]].set_value(q_left_leg(4));
    command_interfaces_[dxls_index_["l_hip_pitch"]].set_value(q_left_leg(3));
    command_interfaces_[dxls_index_["l_knee"]].set_value(q_left_leg(2));
    command_interfaces_[dxls_index_["l_ank_pitch"]].set_value(q_left_leg(1));
    command_interfaces_[dxls_index_["l_ank_roll"]].set_value(q_left_leg(0));

    command_interfaces_[dxls_index_["r_hip_yaw"]].set_value(q_right_leg(5));
    command_interfaces_[dxls_index_["r_hip_roll"]].set_value(q_right_leg(4));
    command_interfaces_[dxls_index_["r_hip_pitch"]].set_value(q_right_leg(3));
    command_interfaces_[dxls_index_["r_knee"]].set_value(q_right_leg(2));
    command_interfaces_[dxls_index_["r_ank_pitch"]].set_value(q_right_leg(1));
    command_interfaces_[dxls_index_["r_ank_roll"]].set_value(q_right_leg(0));

    command_interfaces_[dxls_index_["l_sho_pitch"]].set_value(q_left_arm(0));
    command_interfaces_[dxls_index_["r_sho_pitch"]].set_value(q_right_arm(0));
  }

  //*************************
  // CONCLUDE CONTROL CYCLE:
  //*************************

  iter++;
  auto finish = std::chrono::high_resolution_clock::now();
  auto interval = std::chrono::time_point_cast<std::chrono::microseconds>(finish) -
                  std::chrono::time_point_cast<std::chrono::microseconds>(start);
  std::cout << "time to execute one step of the locomotion controller is " << interval.count() / 1000.0 << " ms"
            << std::endl;
  std::cout << "ITER " << iter << " fsCount " << walkState.footstepCounter << " walkState.controlIter "
            << walkState.controlIter << " operational mode: " << mode << std::endl;

  return controller_interface::return_type::OK;
}

void QuinticWalk::storeEncoderReadings()
{
  for (auto const& state : dxls_key_)
  {
    // double p_pos = dxls_state_[state];
    if (state == "r_sho_pitch")
      q0_right_arm(0) = -1 * dxls_state_[state];
    if (state == "r_sho_roll")
      q0_right_arm(1) = -1 * dxls_state_[state];
    if (state == "r_el")
      q0_right_arm(2) = -1 * dxls_state_[state];

    if (state == "l_sho_pitch")
      q0_left_arm(0) = -1 * dxls_state_[state];
    if (state == "l_sho_roll")
      q0_left_arm(1) = -1 * dxls_state_[state];
    if (state == "l_el")
      q0_left_arm(2) = -1 * dxls_state_[state];

    if (state == "r_hip_yaw")
    {
      q0_right_leg(5) = -1 * dxls_state_[state];
    }
    if (state == "r_hip_roll")
    {
      q0_right_leg(4) = -1 * dxls_state_[state];
    }
    if (state == "r_hip_pitch")
    {
      q0_right_leg(3) = -1 * dxls_state_[state];
    }
    if (state == "r_knee")
    {
      q0_right_leg(2) = -1 * dxls_state_[state];
    }
    if (state == "r_ank_pitch")
    {
      q0_right_leg(1) = dxls_state_[state];
    }
    if (state == "r_ank_roll")
    {
      q0_right_leg(0) = dxls_state_[state];
    }

    if (state == "l_hip_yaw")
    {
      q0_left_leg(5) = -1 * dxls_state_[state];
    }
    if (state == "l_hip_roll")
    {
      q0_left_leg(4) = -1 * dxls_state_[state];
    }
    if (state == "l_hip_pitch")
    {
      q0_left_leg(3) = -1 * dxls_state_[state];
    }
    if (state == "l_knee")
    {
      q0_left_leg(2) = -1 * dxls_state_[state];
      std::cout << state << std::endl;
      std::cout << dxls_state_[state] << std::endl;
    }
    if (state == "l_ank_pitch")
    {
      q0_left_leg(1) = dxls_state_[state];
    }
    if (state == "l_ank_roll")
    {
      q0_left_leg(0) = dxls_state_[state];
    }
  }
}
void QuinticWalk::computeDirectKinematics()
{
  if (walkState.supportFoot == true)
  {
    left_leg_fk_solver->JntToCart(q0_left_leg, x_left_leg_fk);
    for (int i = 0; i < 12; i++)
    {
      if (i < 6)
        q0_sf_to_swg(i) = q0_left_leg(i);
      else
        q0_sf_to_swg(i) = q0_right_leg(11 - i);
    }
    left_foot_to_right_foot_fk_solver->JntToCart(q0_sf_to_swg, x_sf_to_swg);
    CoM_pose_meas.segment(0, 3) = Eigen::Vector3d(x_left_leg_fk.p(0), x_left_leg_fk.p(1), x_left_leg_fk.p(2));
    swg_pose_meas.segment(0, 3) = Eigen::Vector3d(x_sf_to_swg.p(0), x_sf_to_swg.p(1), x_sf_to_swg.p(2));
    x_left_leg_fk.M.GetRPY(CoM_pose_meas(3), CoM_pose_meas(4), CoM_pose_meas(5));
    x_sf_to_swg.M.GetRPY(swg_pose_meas(3), swg_pose_meas(4), swg_pose_meas(5));
  }
  else
  {
    right_leg_fk_solver->JntToCart(q0_right_leg, x_right_leg_fk);
    for (int i = 0; i < 12; i++)
    {
      if (i < 6)
        q0_sf_to_swg(i) = q0_right_leg(i);
      else
        q0_sf_to_swg(i) = q0_left_leg(11 - i);
    }
    right_foot_to_left_foot_fk_solver->JntToCart(q0_sf_to_swg, x_sf_to_swg);
    CoM_pose_meas.segment(0, 3) = Eigen::Vector3d(x_right_leg_fk.p(0), x_right_leg_fk.p(1), x_right_leg_fk.p(2));
    swg_pose_meas.segment(0, 3) = Eigen::Vector3d(x_sf_to_swg.p(0), x_sf_to_swg.p(1), x_sf_to_swg.p(2));
    x_right_leg_fk.M.GetRPY(CoM_pose_meas(3), CoM_pose_meas(4), CoM_pose_meas(5));
    x_sf_to_swg.M.GetRPY(swg_pose_meas(3), swg_pose_meas(4), swg_pose_meas(5));
  }
}

void QuinticWalk::computeInverseKinematicsWholeBody()
{
  Eigen::MatrixXd weights = Eigen::MatrixXd::Identity(12, 12);

  // com pos
  weights(0, 0) = 100.0;
  weights(1, 1) = 100.0;
  weights(2, 2) = 88.0;

  // com orient
  weights(3, 3) = 150.0;
  weights(4, 4) = 150.0;
  weights(5, 5) = 100.0;

  // foot pos
  weights(6, 6) = 100.0;
  weights(7, 7) = 100.0;
  weights(8, 8) = 110.0;

  // foot orient
  weights(9, 9) = 115.0;
  weights(10, 10) = 115.0;
  weights(11, 11) = 110.0;

  // just useful for better performance
  if (iter < 750)
    weights *= 0.5;
  else
    weights *= 0.7;

  // weights *= 1.1;  in real robot

  if (walkState.supportFoot == true)
  {
    // left support foot

    sf_pose << desired.leftFootPos, desired.leftFootOrient;
    CoM_pose_des << desired.comPos, desired.torsoOrient;
    CoM_pose_des(2) = CoM_pose_des(2);
    swg_pose_des << desired.rightFootPos, desired.rightFootOrient;
    CoM_pose_des = vvRel(CoM_pose_des, sf_pose);
    swg_pose_des = vvRel(swg_pose_des, sf_pose);
    CoM_pose_des(0) = CoM_pose_des(0) + sagittal_com_offset;

    Eigen::VectorXd v_des, pos_des, pos_meas;
    v_des = Eigen::VectorXd::Zero(12);
    v_des.segment(0, 3) = desired.comVel;
    pos_des = Eigen::VectorXd::Zero(12);
    pos_meas = Eigen::VectorXd::Zero(12);
    pos_des << CoM_pose_des, swg_pose_des;
    pos_meas << CoM_pose_meas, swg_pose_meas;

    if (left_foot_to_right_foot_jacobian_solver->JntToJac(q0_sf_to_swg, J_leftf_to_rightf_leg) < 0)
    {
      RCLCPP_ERROR(get_node()->get_logger(), "jacobian error");
    }
    J_left_leg_to_right = J_leftf_to_rightf_leg.data;
    if (left_leg_jacobian_solver->JntToJac(q0_left_leg, J_left_leg) < 0)
    {
      RCLCPP_ERROR(get_node()->get_logger(), "jacobian error");
    }
    J_left_leg_ = J_left_leg.data;
    J_stacked << J_left_leg_, Eigen::MatrixXd::Zero(6, 6), J_left_leg_to_right;

    Eigen::VectorXd q_dot = J_stacked.transpose() * (J_stacked * J_stacked.transpose() + Id * sigma).inverse() *
                            (v_des + weights * (pos_des - pos_meas));
    for (int i = 0; i < 6; i++)
      q_left_leg(i) = q0_left_leg(i) + (1.0 / rate) * q_dot(i);
    for (int i = 0; i < 6; i++)
      q_right_leg(5 - i) = q0_right_leg(5 - i) + (1.0 / rate) * q_dot(i + 6);
  }
  else
  {
    // right support foot

    sf_pose << desired.rightFootPos, desired.rightFootOrient;
    CoM_pose_des << desired.comPos, desired.torsoOrient;
    CoM_pose_des(2) = CoM_pose_des(2);
    swg_pose_des << desired.leftFootPos, desired.leftFootOrient;
    CoM_pose_des = vvRel(CoM_pose_des, sf_pose);
    swg_pose_des = vvRel(swg_pose_des, sf_pose);
    CoM_pose_des(0) = CoM_pose_des(0) + sagittal_com_offset;

    Eigen::VectorXd v_des, pos_des, pos_meas;
    v_des = Eigen::VectorXd::Zero(12);
    v_des.segment(0, 3) = desired.comVel;
    pos_des = Eigen::VectorXd::Zero(12);
    pos_meas = Eigen::VectorXd::Zero(12);
    pos_des << CoM_pose_des, swg_pose_des;
    pos_meas << CoM_pose_meas, swg_pose_meas;

    if (right_foot_to_left_foot_jacobian_solver->JntToJac(q0_sf_to_swg, J_rightf_to_leftf_leg) < 0)
    {
      RCLCPP_ERROR(get_node()->get_logger(), "jacobian error");
    }
    J_right_leg_to_left = J_rightf_to_leftf_leg.data;
    if (right_leg_jacobian_solver->JntToJac(q0_right_leg, J_right_leg) < 0)
    {
      RCLCPP_ERROR(get_node()->get_logger(), "jacobian error");
    }
    J_right_leg_ = J_right_leg.data;
    J_stacked << J_right_leg_, Eigen::MatrixXd::Zero(6, 6), J_right_leg_to_left;

    Eigen::VectorXd q_dot = J_stacked.transpose() * (J_stacked * J_stacked.transpose() + Id * sigma).inverse() *
                            (v_des + weights * (pos_des - pos_meas));
    for (int i = 0; i < 6; i++)
      q_right_leg(i) = q0_right_leg(i) + (1.0 / rate) * q_dot(i);
    for (int i = 0; i < 6; i++)
      q_left_leg(5 - i) = q0_left_leg(5 - i) + (1.0 / rate) * q_dot(i + 6);
  }
}
}  // namespace quintic_walk

#include "pluginlib/class_list_macros.hpp"
PLUGINLIB_EXPORT_CLASS(quintic_walk::QuinticWalk, controller_interface::ControllerInterface)