#ifndef QUINTIC_WALK__QUINTIC_WALK_HPP_
#define QUINTIC_WALK__QUINTIC_WALK_HPP_

#include <memory>
#include <thread>
#include <string>
#include <vector>
#include <iostream>
#include <unordered_map>
#include <chrono>
#include <kdl_parser/kdl_parser.hpp>
#include <kdl/chainfksolverpos_recursive.hpp>
#include <kdl/chainiksolvervel_pinv.hpp>
#include <kdl/chainiksolverpos_nr.hpp>
#include <kdl/chainiksolverpos_nr_jl.hpp>
#include <kdl/chainidsolver_recursive_newton_euler.hpp>
#include <kdl/kdl.hpp>
#include <kdl/frames.hpp>
#include <kdl/frames_io.hpp>
#include <kdl/jacobian.hpp>
#include <kdl/chainjnttojacsolver.hpp>
#include <boost/scoped_ptr.hpp>
#include <iostream>
#include <eigen3/Eigen/Eigen>
#include <math.h>
#include <fstream>


#include "hardware_interface/hardware_info.hpp"
#include "hardware_interface/system_interface.hpp"
#include "hardware_interface/types/hardware_interface_return_values.hpp"
#include "hardware_interface/types/hardware_interface_type_values.hpp"
#include "rclcpp/macros.hpp"
#include "rclcpp_lifecycle/node_interfaces/lifecycle_node_interface.hpp"
#include "rclcpp_lifecycle/state.hpp"

#include "controller_interface/controller_interface.hpp"
#include "std_msgs/msg/float64_multi_array.hpp"
#include <std_msgs/msg/int16.hpp>
#include <std_msgs/msg/string.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <sensor_msgs/msg/imu.hpp>
#include "sensor_msgs/msg/joint_state.hpp"
#include "std_msgs/msg/header.hpp"
#include <ament_index_cpp/get_package_share_directory.hpp>
#include "rclcpp/rclcpp.hpp"


#include "QPSolverInterface.cpp"
#include "MPCSolver.hpp"
#include "quintic_walk_parameters.hpp"

namespace quintic_walk
{

class QuinticWalk : public controller_interface::ControllerInterface
{
public:
  controller_interface::CallbackReturn on_init() override;
  controller_interface::InterfaceConfiguration command_interface_configuration() const override;
  controller_interface::InterfaceConfiguration state_interface_configuration() const override;
  controller_interface::CallbackReturn on_configure(const rclcpp_lifecycle::State& previous_state) override;
  controller_interface::CallbackReturn on_activate(const rclcpp_lifecycle::State& previous_state) override;
  controller_interface::CallbackReturn on_deactivate(const rclcpp_lifecycle::State& previous_state) override;
  controller_interface::CallbackReturn on_cleanup(const rclcpp_lifecycle::State& previous_state) override;
  controller_interface::CallbackReturn on_error(const rclcpp_lifecycle::State& previous_state) override;
  controller_interface::CallbackReturn on_shutdown(const rclcpp_lifecycle::State& previous_state) override;
  controller_interface::return_type update(const rclcpp::Time& time, const rclcpp::Duration& period) override;

  void storeEncoderReadings();
  void computeInverseKinematicsWholeBody();
  void computeDirectKinematics();
  void callbackImuGyro(const sensor_msgs::msg::Imu & msg);

private:
  std::shared_ptr<ParamListener> param_listener_;
  Params params_;

  bool enable_ = true;

  std::vector<std::string> dxls_key_;
  std::vector<std::string> sensor_key_;
  std::unordered_map<std::string, double> sensor_state_;
  std::unordered_map<std::string, uint8_t> dxls_index_;
  std::unordered_map<std::string, double> dxls_command_;
  std::unordered_map<std::string, double> dxls_state_;

    // useful attributes
  int control_cycle_msec_;
  std::thread queue_thread_;
  std::string mode;
  double iter;
  double rate;
  double ball_error;
  double T;
  double z0;
  double zf;
  double a0, a1, a2, a3;
  double t;
  int t_start, t_stand, t_walk, t_sit;
  std::ofstream myfile;

  // matrices
  Eigen::MatrixXd J_right_arm_, J_right_leg_, J_left_leg_;  
  Eigen::MatrixXd J_right_leg_to_left, J_left_leg_to_right;    
  Eigen::MatrixXd J_right_arm_resized, J_right_leg_resized, J_left_leg_resized;
  Eigen::MatrixXd J_stacked, Id;          
  
  Eigen::VectorXd x_right_arm_des, x_right_arm_meas, x_right_arm_vel_des;    
  Eigen::VectorXd x_right_leg_des, x_right_leg_meas, x_right_leg_vel_des;     
  Eigen::VectorXd x_left_leg_des, x_left_leg_meas, x_left_leg_vel_des;     
  Eigen::Vector3d rpy, angular_rates, linear_acc;  
  Eigen::VectorXd sf_pose, CoM_pose, swg_pose;   
  Eigen::VectorXd sf_pose_meas, CoM_pose_meas, swg_pose_meas;       
  Eigen::VectorXd CoM_pose_des, swg_pose_des;       

  Eigen::MatrixXd ftsp_and_time; 

  //// KDL ////
  // robot
  KDL::Tree mRobot;

  // kinematic chains
  KDL::Chain op3_right_arm_kinematic_chain_;
  KDL::Chain op3_left_arm_kinematic_chain_;
  KDL::Chain op3_right_leg_kinematic_chain_; // from right support foot to CoM
  KDL::Chain op3_left_leg_kinematic_chain_; // from left support foot to CoM

  KDL::Chain op3_right_foot_to_left_foot_kinematic_chain_; // from right support foot to left foot
  KDL::Chain op3_left_foot_to_right_foot_kinematic_chain_; // from left support foot to right foot

  // ik solvers
  boost::scoped_ptr<KDL::ChainFkSolverPos_recursive> right_arm_fk_solver;
  boost::scoped_ptr<KDL::ChainFkSolverPos> left_arm_fk_solver;
  boost::scoped_ptr<KDL::ChainFkSolverPos> right_leg_fk_solver;
  boost::scoped_ptr<KDL::ChainFkSolverPos> left_leg_fk_solver;
  boost::scoped_ptr<KDL::ChainFkSolverPos> left_foot_to_right_foot_fk_solver;
  boost::scoped_ptr<KDL::ChainFkSolverPos> right_foot_to_left_foot_fk_solver;

  boost::scoped_ptr<KDL::ChainJntToJacSolver> right_arm_jacobian_solver;
  boost::scoped_ptr<KDL::ChainJntToJacSolver> right_leg_jacobian_solver;
  boost::scoped_ptr<KDL::ChainJntToJacSolver> left_leg_jacobian_solver;

  boost::scoped_ptr<KDL::ChainJntToJacSolver> right_foot_to_left_foot_jacobian_solver;
  boost::scoped_ptr<KDL::ChainJntToJacSolver> left_foot_to_right_foot_jacobian_solver;

  // joints and frames
  KDL::JntArray  q_right_arm, q0_right_arm;                                                                                                       
  KDL::JntArrayVel  qdot_right_arm; 
  KDL::Frame     x_right_arm_fk, x_right_arm_d; 
  KDL::Frame     x_right_leg_fk, x_right_leg_d; 
  KDL::Frame     x_left_leg_fk, x_left_leg_d; 
  KDL::JntArray  q_left_arm;                                                                                                       
  KDL::JntArray  q0_left_arm;             
  KDL::JntArrayVel  qdot_left_arm; 
  KDL::Frame     x_left_arm; 
  KDL::JntArray  q_right_leg;                                                                                                       
  KDL::JntArray  q0_right_leg;             
  KDL::JntArrayVel  qdot_right_leg; 
  KDL::Frame     x_right_leg; 
  KDL::JntArray  q_left_leg;                                                                                                       
  KDL::JntArray  q0_left_leg;             
  KDL::JntArrayVel  qdot_left_leg; 
  KDL::Frame     x_left_leg; 
  KDL::Frame     x_sf_to_swg; 
  KDL::JntArray  q_sf_to_swg, q0_sf_to_swg;                                                                                                       

  // other kdl stuff      
  KDL::JntArray  tau_; 
  KDL::Frame     x_; 
  KDL::Frame     xd_;   
  KDL::Frame     x0_;  
  KDL::Twist     xerr_;   
  KDL::Twist     xdot_; 
  KDL::Wrench    F_;  
  KDL::Jacobian  J_right_arm, J_right_leg, J_left_leg, J_rightf_to_leftf_leg, J_leftf_to_rightf_leg;  
  KDL::Twist     Kp_; //gains      
  KDL::Twist     Kd_; 

  // mpc solver and data structures
  MPCSolver* solver;
  State desired;
  State current;
  WalkState walkState;

};

}  // namespace quintic_walk

#endif  // QUINTIC_WALK__QUINTIC_WALK_HPP_
